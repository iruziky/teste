# analise_projeto.py

import os
import ast

def analyze_python_file(filepath):
    """
    (PT) Analisa um arquivo Python e retorna suas classes e funções,
    incluindo os métodos dentro das classes.

    (EN) Analyzes a Python file and returns its classes and functions,
    including methods within classes.
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        try:
            tree = ast.parse(f.read(), filename=filepath)
        except SyntaxError as e:
            print(f"  -> SyntaxError in {filepath}: {e}")
            return []

    results = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            results.append(f"  - def {node.name}()")
        elif isinstance(node, ast.ClassDef):
            results.append(f"  - class {node.name}:")
            for method in node.body:
                if isinstance(method, ast.FunctionDef):
                    results.append(f"    - def {method.name}()")
    return results

def main():
    """(PT) Percorre a pasta 'src' e imprime a estrutura do projeto."""
    """(EN) Traverses the 'src' folder and prints the project structure."""
    root_dir = 'src'
    for subdir, _, files in os.walk(root_dir):
        if '__pycache__' in subdir:
            continue
        
        for file in sorted(files):
            if file.endswith('.py'):
                filepath = os.path.join(subdir, file)
                if file == '__init__.py' and os.path.getsize(filepath) == 0:
                    continue

                print(f"{filepath}:")
                
                structure = analyze_python_file(filepath)
                for line in structure:
                    print(line)
                
                if structure:
                    print()

if __name__ == "__main__":
    main()
