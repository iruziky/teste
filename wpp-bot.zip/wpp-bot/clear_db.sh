#!/bin/bash

# Este script limpa a tabela 'conversations' no banco de dados SQLite.
echo "Limpando a tabela 'conversations'..."

# Executa o comando DELETE FROM dentro do contêiner 'worker'
docker compose exec worker sqlite3 /app/database/conversations.db "DELETE FROM conversations;"

echo "Limpeza concluída."