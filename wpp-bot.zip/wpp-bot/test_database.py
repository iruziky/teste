#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
from datetime import datetime

# Adicionar o diretório raiz ao path
sys.path.insert(0, os.path.abspath('.'))

from src.database.models import DatabaseManager, Conversation
from src.database.crud import ConversationCRUD

def test_database():
    print("=== Teste do Banco de Dados SQLite ===")
    
    # Criar diretório para o banco de dados de teste
    os.makedirs('test_database', exist_ok=True)
    
    # Inicializar o banco de dados
    db_manager = DatabaseManager(database_url='sqlite:///test_database/test_conversations.db')
    print("✓ Banco de dados inicializado")
    
    # Obter uma sessão
    db_session = db_manager.get_session()
    print("✓ Sessão do banco de dados criada")
    
    try:
        # Teste 1: Criar uma nova conversa
        print("\n--- Teste 1: Criar nova conversa ---")
        chat_id = "5511999999999@c.us"
        conversation = ConversationCRUD.create_conversation(
            db_session, 
            client_contact=chat_id,
            current_step="inicio",
            conversation_status="IN_PROGRESS"
        )
        print(f"✓ Conversa criada: {conversation}")
        
        # Teste 2: Adicionar mensagens ao histórico
        print("\n--- Teste 2: Adicionar mensagens ---")
        user_message = {
            "type": "user",
            "content": "Olá, gostaria de saber mais sobre seus produtos",
            "timestamp": datetime.now().isoformat()
        }
        ConversationCRUD.add_message_to_conversation(db_session, chat_id, user_message)
        print("✓ Mensagem do usuário adicionada")
        
        bot_message = {
            "type": "bot", 
            "content": "Olá! Fico feliz em ajudar. Temos vários produtos disponíveis...",
            "timestamp": datetime.now().isoformat()
        }
        ConversationCRUD.add_message_to_conversation(db_session, chat_id, bot_message)
        print("✓ Mensagem do bot adicionada")
        
        # Teste 3: Buscar conversa
        print("\n--- Teste 3: Buscar conversa ---")
        found_conversation = ConversationCRUD.get_conversation(db_session, chat_id)
        print(f"✓ Conversa encontrada: {found_conversation.client_contact}")
        print(f"  Status: {found_conversation.conversation_status}")
        print(f"  Histórico: {len(found_conversation.get_history_as_list())} mensagens")
        
        # Teste 4: Atualizar conversa
        print("\n--- Teste 4: Atualizar conversa ---")
        ConversationCRUD.update_conversation(
            db_session, 
            chat_id, 
            current_step="interesse_demonstrado",
            conversation_status="IN_PROGRESS"
        )
        print("✓ Conversa atualizada")
        
        # Teste 5: Fechar conversa
        print("\n--- Teste 5: Fechar conversa ---")
        ConversationCRUD.close_conversation(
            db_session, 
            chat_id, 
            "STOP_CONVERSATION_GOOD",
            "Cliente demonstrou interesse e agendou uma reunião"
        )
        print("✓ Conversa fechada com sucesso")
        
        # Verificar estado final
        final_conversation = ConversationCRUD.get_conversation(db_session, chat_id)
        print(f"  Status final: {final_conversation.conversation_status}")
        print(f"  Histórico final: {len(final_conversation.get_history_as_list())} mensagens")
        
        print("\n=== Todos os testes passaram! ===")
        
    except Exception as e:
        print(f"❌ Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db_session.close()
        print("✓ Sessão do banco de dados fechada")

if __name__ == "__main__":
    test_database()
