// static/scripts.js

document.addEventListener('DOMContentLoaded', () => {

    // --- Elementos Comuns ---
    const massSendSection = document.getElementById('massSendSection');
    const uploadForm = document.getElementById('uploadForm');

    // Limpa o formulário no carregamento para uma experiência consistente.
    if (uploadForm) {
        uploadForm.reset();
    }

    // --- Função Auxiliar para Mostrar Secção da Campanha ---
    const showCampaignSection = () => {
        if (massSendSection) {
            massSendSection.classList.remove('hidden');
        }
    };

    // --- Lógica do QR Code ---
    const qrImage = document.getElementById('qrImage');
    const qrStatus = document.getElementById('qrStatus');
    const generateButton = document.getElementById('generateButton');
    const qrLoader = document.getElementById('qrLoader');

    if (generateButton) {
        generateButton.addEventListener('click', async () => {
            qrStatus.textContent = 'Gerando QR Code, por favor aguarde...';
            qrStatus.className = 'status-text';
            qrImage.style.display = 'none';
            qrLoader.style.display = 'block';
            generateButton.disabled = true;
            generateButton.textContent = 'Aguarde...';

            try {
                const response = await fetch('/generate-qr', { method: 'POST' });
                const data = await response.json();

                if (response.ok) {
                    showCampaignSection();

                    if (data.status === 'ALREADY_CONNECTED') {
                        qrLoader.style.display = 'none';
                        qrStatus.textContent = '✅ Sucesso! O bot já está conectado.';
                        qrStatus.classList.add('success');
                        generateButton.textContent = 'Conectado';
                        generateButton.disabled = true;
                    } else { 
                        qrLoader.style.display = 'none';
                        qrStatus.textContent = 'Pronto! Escaneie o código abaixo:';
                        qrStatus.classList.add('success');
                        qrImage.src = '/qrcode.png?t=' + new Date().getTime();
                        qrImage.style.display = 'block';
                        generateButton.textContent = 'Gerar Novo Código';
                    }
                } else {
                    throw new Error(data.error || "Ocorreu uma falha no servidor.");
                }
            } catch (error) {
                qrLoader.style.display = 'none';
                qrStatus.textContent = `Erro: ${error.message}`;
                qrStatus.classList.add('error');
                generateButton.textContent = 'Tentar Novamente';
            } finally {
                if (generateButton.textContent !== 'Conectado') {
                    generateButton.disabled = false;
                }
            }
        });
    }

    // --- Lógica de Upload de CSV ---
    const csvFileInput = document.getElementById('csvFile');
    const fileNameDisplay = document.getElementById('fileName');
    const uploadButton = document.getElementById('uploadButton');
    const uploadStatus = document.getElementById('uploadStatus');

    if (csvFileInput && uploadButton) {
        csvFileInput.addEventListener('change', () => {
            if (csvFileInput.files.length > 0) {
                fileNameDisplay.textContent = csvFileInput.files[0].name;
                uploadStatus.textContent = '';
                uploadButton.disabled = false; // Ativa o botão
            } else {
                fileNameDisplay.textContent = 'Selecionar ficheiro CSV';
                uploadButton.disabled = true; // Desativa o botão
            }
        });

        uploadButton.addEventListener('click', async () => {
            if (csvFileInput.files.length === 0) {
                uploadStatus.textContent = 'Por favor, selecione um ficheiro primeiro.';
                uploadStatus.className = 'status-text error';
                return;
            }
            const file = csvFileInput.files[0];

            uploadStatus.textContent = 'Enviando arquivo...';
            uploadStatus.className = 'status-text';
            uploadButton.disabled = true;
            uploadButton.textContent = 'Aguarde...';

            const formData = new FormData();
            formData.append('contact_list', file);

            try {
                const response = await fetch('/upload-and-start', {
                    method: 'POST',
                    body: formData,
                });
                const data = await response.json();

                if (response.ok) {
                    uploadStatus.textContent = data.message || 'Campanha iniciada com sucesso!';
                    uploadStatus.classList.add('success');
                } else {
                    throw new Error(data.error || 'Ocorreu uma falha no servidor.');
                }
            } catch (error) {
                uploadStatus.textContent = `Erro: ${error.message}`;
                uploadStatus.classList.add('error');
            } finally {
                uploadButton.disabled = true; // Mantém desativado após o envio
                uploadButton.textContent = 'Enviar e Iniciar Campanha';
                if(uploadForm) {
                    uploadForm.reset();
                }
                fileNameDisplay.textContent = 'Selecionar ficheiro CSV';
            }
        });
    }
});
