# src/config.py

import os

class Config:
    """
    (PT) Agrupa todas as variáveis de configuração da aplicação.
    Lê a partir de variáveis de ambiente para ser compatível com Docker.

    (EN) Groups all application configuration variables.
    Reads from environment variables to be Docker-compatible.
    """
    BOT_OWN_CHAT_ID = os.getenv("BOT_OWN_CHAT_ID")
    
    CONTACTS_TO_IGNORE_SEND = "src/assets/ignorar_contatos.csv"
    
    SALES_SCRIPT = "src/assets/roteiro.yml"
    
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY')
    
    REDIS_HOST = os.getenv("REDIS_HOST", "redis")
    REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
    REDIS_QUEUE_KEY = os.getenv("REDIS_QUEUE_KEY", "whatsapp_jobs")
    WAHA_URL = os.getenv("WAHA_URL", "http://waha:3000")
    SESSION_NAME = os.getenv("SESSION_NAME", "default")
    
    # Configuração do banco de dados
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///database/conversations.db")
