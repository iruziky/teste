import os
import logging
import redis
import json
import time
import threading

from src.approach.mass_sending import MassSendHandler
from src.dialogue_manager.handler import DialogueHandler
from src.services.token_counter import TokenCounter
from src.services.llm_service import LLMService
from src.config import Config
from src.services.waha import WahaClient
from src.database.models import DatabaseManager, Conversation
from src.database.crud import ConversationCRUD

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - [WORKER] - %(message)s'
)
logger = logging.getLogger(__name__)

class Worker:
    """
    (PT) Encapsula toda a lógica para o processador de tarefas em segundo plano.
    Ele escuta uma fila do Redis e processa trabalhos à medida que chegam.

    (EN) Encapsulates all the logic for the background job processor.
    It listens to a Redis queue and processes jobs as they arrive.
    """

    def __init__(self):
        """
        (PT) Inicializa o Worker, suas configurações, conexões e serviços.
        """
        self._load_config()
        self._connect_to_redis()

        self.config = Config()
        self.bot_own_chat_id = self.config.BOT_OWN_CHAT_ID

        # Inicializar o banco de dados
        self.db_manager = DatabaseManager(database_url=self.config.DATABASE_URL)

        self.waha_client = WahaClient(api_url=self.config.WAHA_URL)
        self.mass_sending = MassSendHandler(waha_client=self.waha_client, config=self.config)
        
        token_counter_instance = TokenCounter()
        llm_service_instance = LLMService(token_counter_instance)
        script_path = self.config.SALES_SCRIPT
        self.dialogue_handler = DialogueHandler(llm_service=llm_service_instance, script_path=script_path)  
        
        self.debounce_timers = {}
        logger.info("Worker initialized with all services ready.")

    def _load_config(self):
        """ (PT) Carrega as configurações do worker. (EN) Loads worker configurations. """
        self.redis_host = os.getenv("REDIS_HOST", "redis")
        self.redis_port = int(os.getenv("REDIS_PORT", 6379))
        self.redis_queue_key = os.getenv("REDIS_QUEUE_KEY", "whatsapp_jobs")
        self.debounce_seconds = int(os.getenv("DEBOUNCE_SECONDS", 3))

    def _connect_to_redis(self):
        """ (PT) Estabelece as conexões com o Redis. (EN) Establishes Redis connections. """
        try:
            self.job_queue_client = redis.StrictRedis(
                host=self.redis_host, port=self.redis_port, decode_responses=True
            )
            self.message_cache_client = redis.StrictRedis(
                host=self.redis_host, port=self.redis_port, db=1, decode_responses=True
            )
            self.job_queue_client.ping()
            logger.info("Successfully connected to Redis.")
        except redis.exceptions.ConnectionError as e:
            logger.critical(f"Could not connect to Redis: {e}", exc_info=True)
            raise

    def _process_debounced_message(self, chat_id: str):
        """
        (PT) Processa a mensagem do usuário e despacha a ação correta
        com base na decisão da IA (continuar, parar com sucesso, ou parar por desistência).

        (EN) Processes the user's message and dispatches the correct action
        based on the AI's decision (continue, stop successfully, or stop due to drop-off).
        """
        db_session = None
        user_data_json_at_start = self.message_cache_client.get(chat_id)

        if not user_data_json_at_start:
            logger.warning(f"Aborting processing for {chat_id}: no data in cache (might be a cancelled job).")
            return

        try:
            user_data = json.loads(user_data_json_at_start)
            full_message = " ".join(user_data["messages"])
            logger.info(f"Processing bundled message for {chat_id}: '{full_message}'")

            db_session = self.db_manager.get_session()
            
            conversation = ConversationCRUD.get_or_create_conversation(db_session, chat_id)
            if not conversation:
                logger.error(f"Failed to get or create conversation for {chat_id}")
                return
            
            user_message_dict = {
                "type": "user", "content": full_message, "timestamp": time.time()
            }
            ConversationCRUD.add_message_to_conversation(db_session, chat_id, user_message_dict)
            
            history_from_db = conversation.get_history_as_list()
            
            decision = self.dialogue_handler.generate_reply(
                chat_history=history_from_db, user_message=full_message
            )

            reply_message = decision.get("reply_message")
            final_status = decision.get("final_status")
            summary = decision.get("summary")

            if reply_message:
                bot_message_dict = {
                    "type": "bot", "content": reply_message, "timestamp": time.time()
                }
                ConversationCRUD.add_message_to_conversation(db_session, chat_id, bot_message_dict)

            if final_status == 'STOP_SUCCESS':
                logger.info(f"Conversation with {chat_id} ended successfully. Sending internal summary.")
                ConversationCRUD.close_conversation(db_session, chat_id, "STOP_CONVERSATION_GOOD", summary)
                self.message_cache_client.delete(chat_id)
                if summary and self.bot_own_chat_id:
                    internal_notification = (
                        f"🎉 Conversa finalizada com sucesso! 🎉\n\n"
                        f"👤 *Cliente (Chat ID):*\n`{chat_id[2:-5]}`\n\n"
                        f"📝 *Resumo da Conversa:*\n{summary}"
                    )
                    self.waha_client.send_text(chat_id=self.bot_own_chat_id, text=internal_notification)

            elif final_status == 'STOP_BAD_LEAD':
                logger.warning(f"Conversation with {chat_id} stopped by user request. No reply sent.")
                ConversationCRUD.close_conversation(db_session, chat_id, "STOP_CONVERSATION_BAD")
                self.message_cache_client.delete(chat_id)

            elif final_status == 'CONTINUE':
                ConversationCRUD.update_conversation(db_session, chat_id, conversation_status="IN_PROGRESS")
                if reply_message:
                    self.waha_client.mark_chat_as_read(chat_id)
                    self.waha_client.start_typing(chat_id=chat_id)
                    time.sleep(min(len(reply_message) * 0.08, 5))
                    
                    current_user_data_in_cache = self.message_cache_client.get(chat_id)
                    if current_user_data_in_cache != user_data_json_at_start:
                        logger.info(f"New message arrived for {chat_id} during processing. Aborting send.")
                        return

                    self.waha_client.send_text(chat_id=chat_id, text=reply_message)
                    self.message_cache_client.delete(chat_id)

        except Exception as e:
            logger.error(f"Error processing message for {chat_id}: {e}", exc_info=True)
            self.message_cache_client.delete(chat_id)
        finally:
            if db_session:
                db_session.close()
            self.waha_client.stop_typing(chat_id=chat_id)

    def _handle_user_message(self, chat_id: str, message: str):
        """ (PT) Aplica a lógica de debounce. (EN) Applies debounce logic. """
        # INÍCIO DA MODIFICAÇÃO: Verificação de status da conversa
        db_session = self.db_manager.get_session()
        try:
            conversation = db_session.query(Conversation).filter(Conversation.client_contact == chat_id).first()
            # Verifica se a conversa existe e se o status dela começa com "STOP_"
            if conversation and conversation.conversation_status and conversation.conversation_status.startswith("STOP_"):
                logger.info(f"Ignoring message from {chat_id} because the conversation is closed with status: {conversation.conversation_status}")
                return  # Para a execução aqui e não responde ao usuário
        finally:
            db_session.close()
        # FIM DA MODIFICAÇÃO

        if chat_id in self.debounce_timers and self.debounce_timers[chat_id].is_alive():
            self.debounce_timers[chat_id].cancel()
        
        user_data_json = self.message_cache_client.get(chat_id)
        user_data = json.loads(user_data_json) if user_data_json else {"messages": []}
        user_data["messages"].append(message)
        self.message_cache_client.set(chat_id, json.dumps(user_data), ex=300)
        logger.info(f"Message from {chat_id} added to cache. New timer set.")

        timer = threading.Timer(self.debounce_seconds, self._process_debounced_message, args=[chat_id])
        self.debounce_timers[chat_id] = timer
        timer.start()

    def _normalize_chat_id(self, number_str: str) -> str:
        """
        (PT) Garante que o número de telefone esteja no formato correto para o banco de dados,
        aceitando formatos como "+55 84 9999-9999".
        (EN) Ensures the phone number is in the correct format for the database,
        accepting formats like "+55 84 9999-9999".
        """
        # CORREÇÃO: Remove todos os caracteres não numéricos para lidar com +, -, espaços, etc.
        clean_number = "".join(filter(str.isdigit, number_str))
        
        # CORREÇÃO: Lógica mais robusta para adicionar o DDI 55
        # Se o número tiver 11 dígitos ou menos, assume-se que não tem DDI e o adiciona.
        # Ex: 84999999999 (11 dígitos) -> 5584999999999
        if len(clean_number) <= 11:
            clean_number = '55' + clean_number
        
        if not clean_number.endswith('@c.us'):
            clean_number += '@c.us'
            
        return clean_number

    def _handle_admin_command(self, message: str):
        """
        (PT) Processa comandos enviados pelo administrador do bot.
        (EN) Processes commands sent by the bot administrator.
        """
        if not message.startswith('/'):
            logger.info(f"Ignoring non-command message from BOT_OWN_CHAT_ID: '{message}'")
            return

        parts = message.strip().split()
        command = parts[0].lower()
        
        db_session = self.db_manager.get_session()
        try:
            # CORREÇÃO: Junta todas as partes após o comando para formar o número completo.
            argument_str = " ".join(parts[1:])

            if command == '/stop':
                if not argument_str:
                    self.waha_client.send_text(self.bot_own_chat_id, "Uso incorreto. Use: /stop {número}")
                    return
                target_number = self._normalize_chat_id(argument_str)

                if target_number == self.bot_own_chat_id:
                    self.waha_client.send_text(self.bot_own_chat_id, "❌ Ação não permitida. Você não pode usar o comando /stop no seu próprio número.")
                    return

                success = ConversationCRUD.close_conversation(db_session, target_number, "STOP_CONVERSATION_GOOD")
                if success:
                    self.waha_client.send_text(self.bot_own_chat_id, f"✅ Conversa com {target_number} marcada como finalizada.")
                    logger.info(f"Admin command: Conversation stopped for {target_number}")
                else:
                    self.waha_client.send_text(self.bot_own_chat_id, f"❌ Não foi possível encontrar a conversa com o número: {target_number[:-5]}")

            elif command == '/clean':
                if not argument_str:
                    self.waha_client.send_text(self.bot_own_chat_id, "Uso incorreto. Use: /clean {número}")
                    return
                target_number = self._normalize_chat_id(argument_str)
                conversation_to_delete = db_session.query(Conversation).filter(Conversation.client_contact == target_number).first()
                if conversation_to_delete:
                    db_session.delete(conversation_to_delete)
                    db_session.commit()
                    self.waha_client.send_text(self.bot_own_chat_id, f"🗑️ Histórico da conversa com {target_number} foi excluído.")
                    logger.info(f"Admin command: Conversation history cleaned for {target_number}")
                else:
                    self.waha_client.send_text(self.bot_own_chat_id, f"❌ Não foi possível encontrar a conversa com o número: {target_number}")

            elif command == '/help' or command.startswith('/'):
                help_text = (
                    "🤖 *Comandos Disponíveis* 🤖\n\n"
                    "*/stop {número}*\n"
                    "_Marca uma conversa como finalizada, fazendo o bot parar de responder._\n\n"
                    "*/clean {número}*\n"
                    "_Exclui todo o histórico de uma conversa do banco de dados._\n\n"
                    "*/help*\n"
                    "_Mostra esta mensagem de ajuda._\n\n"
                    "*Exemplo de uso:*\n"
                    "/stop +55 11 99999-8888\n\n"
                    "_*Aviso:* Não é necessário inserir o 9º dígito adicional._"
                )
                self.waha_client.send_text(self.bot_own_chat_id, help_text)

        except Exception as e:
            logger.error(f"Error processing admin command '{message}': {e}", exc_info=True)
            self.waha_client.send_text(self.bot_own_chat_id, f"🚨 Ocorreu um erro ao processar o comando: {command}")
        finally:
            db_session.close()

    def _dispatch_job(self, job_json: str):
        """ (PT) Direciona o job para a função correta. (EN) Routes the job to the correct handler. """
        try:
            job = json.loads(job_json)
            job_type = job.get("job_type")
            payload = job.get("payload", {})
            logger.info(f"Received job of type: {job_type}")
            
            chat_id = payload.get("chat_id")
            message = payload.get("message")

            # ROTA DE ADMIN
            if chat_id == self.bot_own_chat_id:
                if message and message.strip():
                    self._handle_admin_command(message)
                else:
                    logger.info("Ignoring non-message event from BOT_OWN_CHAT_ID.")
                return

            # ROTA DE USUÁRIO NORMAL
            if job_type == "process_message":
                if chat_id and chat_id.endswith('@c.us') and message and message.strip():
                    self._handle_user_message(chat_id, message)
                else:
                    logger.info(f"Ignoring event: not a user message or empty. chat_id: {chat_id}.")
            
            # ROTA DE ENVIO EM MASSA (Existente)
            elif job_type == "process_csv_and_send":
                csv_contacts = payload.get("file_path")
                if csv_contacts:
                    threading.Thread(target=self.mass_sending._handle_mass_send, args=(csv_contacts,)).start()
                else:
                    logger.warning(f"Invalid payload for 'process_csv_and_send': {payload}")
            else:
                logger.warning(f"Unknown job type received: {job_type}")
        except Exception as e:
            logger.error(f"Error dispatching job: {e}", exc_info=True)

    def run(self):
        """ (PT) Inicia o loop principal do worker. (EN) Starts the main worker loop. """
        logger.info("Worker started. Waiting for jobs...")
        while True:
            try:
                _, job_json = self.job_queue_client.brpop(self.redis_queue_key, 0)
                self._dispatch_job(job_json)
            except redis.exceptions.ConnectionError as e:
                logger.error(f"Redis connection lost: {e}. Reconnecting in 5s...")
                time.sleep(5)
                self._connect_to_redis()
            except Exception as e:
                logger.error(f"Unexpected error in main loop: {e}", exc_info=True)

if __name__ == '__main__':
    worker = Worker()
    worker.run()