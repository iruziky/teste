# src/utils/helpers.py

import re
from typing import List, Dict, Tuple

def clean_llm_response(raw_text: str) -> str:
    """
    (PT) Extrai uma string JSON de um texto bruto, que pode estar envolta
    em blocos de código markdown ou texto adicional.
    (EN) Extracts a JSON string from raw text, which might be wrapped
    in markdown code blocks or additional text.
    """
    if not isinstance(raw_text, str):
        return ""

    match = re.search(r'```(json)?\s*(\{.*?\})\s*```', raw_text, re.DOTALL)
    if match:
        return match.group(2)
    
    start = raw_text.find('{')
    end = raw_text.rfind('}')
    if start != -1 and end != -1 and end > start:
        return raw_text[start:end+1]

    return raw_text

def format_chat_history(history_messages: List[Dict]) -> Tuple[str, int]:
    """
    (PT) Formata o histórico de mensagens do WAHA em uma string legível,
    garantindo que cada mensagem seja claramente separada para a IA.

    (EN) Formats the WAHA message history into a readable string,
    ensuring each message is clearly separated for the AI.

    Args:
        history_messages (List[Dict]): A lista de mensagens do histórico.

    Returns:
        Tuple[str, int]: Uma tupla contendo a string do histórico formatado
                         e a contagem de mensagens.
    """
    if not history_messages:
        return "", 0

    formatted_history = []

    for msg in reversed(history_messages):
        if isinstance(msg, dict):
            sender = "Cliente"
            if msg.get("type") == "bot":
                sender = "Vendedor"
            body = msg.get('content', '[mensagem vazia]')
            formatted_history.append(f"{sender}: {body}")

    return "\n\n".join(formatted_history), len(formatted_history)
