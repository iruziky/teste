# src/services/calendar_client.py

import os
import logging
from typing import Optional, Tuple, List, Dict

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build, Resource
from googleapiclient.errors import HttpError

logger = logging.getLogger(__name__)

# (PT) O escopo define o nível de permissão que pedimos.
# '.../auth/calendar' permite ler e escrever eventos.
# (EN) The scope defines the permission level we ask for.
# '.../auth/calendar' allows reading and writing events.
SCOPES = ['https://www.googleapis.com/auth/calendar']

class GoogleCalendarClient:
    """
    (PT) Um cliente para interagir com a API do Google Agenda, gerindo o fluxo OAuth 2.0.
    (EN) A client to interact with the Google Calendar API, managing the OAuth 2.0 flow.
    """

    def __init__(self, client_secrets_path: str, redirect_uri: str):
        """
        (PT) Inicializa o cliente com o caminho para os segredos e o URI de redirecionamento.
        (EN) Initializes the client with the path to the secrets and the redirect URI.
        """
        self.client_secrets_path = client_secrets_path
        self.redirect_uri = redirect_uri
        self.service: Optional[Resource] = None

    def get_auth_url(self) -> Optional[str]:
        """
        (PT) Gera o URL de autorização para o qual o utilizador deve ser redirecionado.
        (EN) Generates the authorization URL to which the user should be redirected.
        """
        try:
            flow = Flow.from_client_secrets_file(
                self.client_secrets_path,
                scopes=SCOPES,
                redirect_uri=self.redirect_uri
            )
            auth_url, _ = flow.authorization_url(prompt='consent')
            return auth_url
        except FileNotFoundError:
            logger.error(f"Client secrets file not found at: {self.client_secrets_path}")
            return None
        except Exception as e:
            logger.error(f"Failed to generate auth URL: {e}", exc_info=True)
            return None

    def fetch_token(self, authorization_code: str) -> Optional[str]:
        """
        (PT) Troca um código de autorização por um refresh token.
        (EN) Exchanges an authorization code for a refresh token.
        """
        try:
            flow = Flow.from_client_secrets_file(
                self.client_secrets_path,
                scopes=SCOPES,
                redirect_uri=self.redirect_uri
            )
            flow.fetch_token(code=authorization_code)
            
            # (PT) O refresh token é o que guardamos para uso futuro.
            # (EN) The refresh token is what we save for future use.
            refresh_token = flow.credentials.refresh_token
            logger.info("Successfully fetched refresh token.")
            return refresh_token
        except Exception as e:
            logger.error(f"Failed to fetch token: {e}", exc_info=True)
            return None

    def build_service_from_token(self, refresh_token: str) -> bool:
        """
        (PT) Constrói o objeto de serviço da API usando um refresh token guardado.
        (EN) Builds the API service object using a stored refresh token.
        """
        try:
            creds = Credentials.from_authorized_user_info(
                info={'refresh_token': refresh_token},
                scopes=SCOPES
            )
            self.service = build('calendar', 'v3', credentials=creds)
            logger.info("Google Calendar service built successfully.")
            return True
        except Exception as e:
            logger.error(f"Failed to build service from token: {e}", exc_info=True)
            return False

    def find_available_slots(self, calendar_id: str = 'primary', time_min: str = '', time_max: str = '') -> Optional[List]:
        """
        (PT) Encontra os horários livres numa agenda específica. (Exemplo)
        (EN) Finds free slots in a specific calendar. (Example)
        """
        if not self.service:
            logger.error("Service not built. Call build_service_from_token first.")
            return None
        try:
            # (PT) A lógica para encontrar horários livres é complexa.
            # Este é um exemplo simples que apenas lista os próximos 10 eventos.
            # (EN) The logic for finding free slots is complex.
            # This is a simple example that just lists the next 10 events.
            events_result = self.service.events().list(
                calendarId=calendar_id,
                timeMin=time_min,
                maxResults=10,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            events = events_result.get('items', [])
            logger.info(f"Found {len(events)} upcoming events.")
            return events
        except HttpError as e:
            logger.error(f"An error occurred while fetching events: {e}")
            return None
