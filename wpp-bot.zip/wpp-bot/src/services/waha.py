# src/services/waha.py

import logging
from typing import Dict, Any, List, Optional
import requests
from requests.exceptions import RequestException

logger = logging.getLogger(__name__)

class WahaClient:
    """
    (PT) Um cliente robusto para interagir com a API do WAHA (WhatsApp HTTP API).
    Gerencia a comunicação, tratamento de erros e logging para todas as interações.

    (EN) A robust client for interacting with the WAHA (WhatsApp HTTP API).
    Manages communication, error handling, and logging for all interactions.
    """

    def __init__(self, api_url: str, session_name: str = "default"):
        """
        (PT) Inicializa o cliente WAHA.

        (EN) Initializes the WAHA client.

        Args:
            api_url (str): A URL base da API do WAHA (ex: 'http://waha:3000').
            session_name (str): O nome da sessão a ser usada nas requisições.
        """
        self.api_url = api_url.rstrip('/')
        self.session_name = session_name
        self.session = requests.Session()
        self.session.headers.update({'Content-Type': 'application/json'})

    def _make_request(self, method: str, endpoint: str, **kwargs) -> Optional[Dict[str, Any]]:
        """
        (PT) Um método privado para fazer todas as requisições HTTP, com tratamento de erro centralizado.

        (EN) A private helper method to make all HTTP requests, with centralized error handling.

        Args:
            method (str): O método HTTP ('GET', 'POST').
            endpoint (str): O endpoint da API a ser chamado.
            **kwargs: Outros argumentos para a chamada do requests (json, params).

        Returns:
            Optional[Dict[str, Any]]: O corpo da resposta em JSON, ou None se ocorrer um erro.
        """
        url = f"{self.api_url}/api/{endpoint}"
        try:
            response = self.session.request(method, url, timeout=15, **kwargs)
            response.raise_for_status()
            
            if response.content:
                return response.json()
            return None
        except RequestException as e:
            logger.error(f"WAHA API request failed to {url}. Error: {e}")
        except ValueError as e:
            logger.error(f"Failed to decode JSON from WAHA API at {url}. Error: {e}")
        
        return None

    def send_text(self, chat_id: str, text: str):
        """
        (PT) Envia uma mensagem de texto para um chat específico.

        (EN) Sends a text message to a specific chat.
        """
        payload = {
            'session': self.session_name,
            'chatId': chat_id,
            'text': text,
        }
        self._make_request('POST', 'sendText', json=payload)

    def get_messages(self, chat_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        (PT) Obtém as últimas mensagens de um chat.

        (EN) Gets the latest messages from a chat.
        """
        endpoint = f"{self.session_name}/chats/{chat_id}/messages"
        params = {'limit': limit, 'downloadMedia': 'false'}
        response_data = self._make_request('GET', endpoint, params=params)
        return response_data if response_data is not None else []

    def start_typing(self, chat_id: str):
        """
        (PT) Mostra o indicador de "digitando..." em um chat.

        (EN) Shows the "typing..." indicator in a chat.
        """
        payload = {'session': self.session_name, 'chatId': chat_id}
        self._make_request('POST', 'startTyping', json=payload)

    def stop_typing(self, chat_id: str):
        """
        (PT) Para o indicador de "digitando..." em um chat.

        (EN) Stops the "typing..." indicator in a chat.
        """
        payload = {'session': self.session_name, 'chatId': chat_id}
        self._make_request('POST', 'stopTyping', json=payload)

    def mark_chat_as_read(self, chat_id: str):
        """
        (PT) Marca as mensagens de um chat como lidas.

        (EN) Marks messages in a chat as read.
        """
        endpoint = f"{self.session_name}/chats/{chat_id}/messages/read"
        self._make_request('POST', endpoint)
