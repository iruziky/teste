# src/bot/core/llm_service.py

import os
import logging
from typing import List

import google.generativeai as genai
from langchain_core.messages import HumanMessage

from src.services.token_counter import TokenCounter

logger = logging.getLogger(__name__)

class LLMService:
    """
    (PT) Encapsula a interação com os modelos de linguagem do Google Gemini.
    Gerencia a configuração, a seleção de modelos e a contagem de tokens.

    (EN) Encapsulates interaction with the Google Gemini language models.
    Manages configuration, model selection, and token counting.
    """

    def __init__(self, token_counter: TokenCounter):
        """
        (PT) Inicializa o serviço de LLM. Configura a API e pré-carrega os modelos.

        (EN) Initializes the LLM service. Configures the API and pre-loads the models.

        Args:
            token_counter (TokenCounter): A instância do contador de tokens a ser usada.
        """
        api_key = os.getenv('GEMINI_API_KEY')
        if not api_key:
            logger.critical("The GEMINI_API_KEY environment variable was not found.")
            raise ValueError("GEMINI_API_KEY is not configured in your environment.")

        try:
            genai.configure(api_key=api_key)
        except Exception as e:
            logger.critical(f"Failed to configure Gemini API. Error: {e}")
            raise

        self.token_counter = token_counter

        self.models = {
            'flash': genai.GenerativeModel(model_name='gemini-1.5-flash'),
            'pro': genai.GenerativeModel(model_name='gemini-2.5-flash')
        }
        logger.info("LLMService initialized with 'flash' and 'pro' models.")

    def generate_text(self, model_name: str, prompt_content: str, log_prefix: str = "LLM") -> str:
        """
        (PT) Gera texto usando um modelo LLM especificado, contando tokens e registrando logs.
        Esta função abstrai a complexidade de interagir diretamente com a API do Gemini.

        (EN) Generates text using a specified LLM model, counting tokens and logging.
        This function abstracts the complexity of interacting directly with the Gemini API.

        Args:
            model_name (str): O nome do modelo a ser usado (ex: 'flash', 'pro').
            prompt_content (str): O prompt específico para esta chamada.
            log_prefix (str): Um prefixo para os logs para fácil identificação.

        Returns:
            str: O texto gerado pelo modelo.
        
        Raises:
            ValueError: Se o model_name solicitado não existir.
            RuntimeError: Se a comunicação com a API do Gemini falhar.
        """
        model = self.models.get(model_name)
        if not model:
            logger.error(f"Attempted to use a non-existent model: '{model_name}'")
            raise ValueError(f"Model '{model_name}' is not available.")

        try:
            input_token_count = model.count_tokens(prompt_content).total_tokens
            self.token_counter.record_input_tokens(model.model_name, input_token_count)
            logger.info(f"[{log_prefix}] Input Tokens: {input_token_count} for model {model.model_name}.")
        except Exception as e:
            logger.warning(f"[{log_prefix}] Failed to count input tokens: {e}")

        logger.debug(f"[{log_prefix}] Prompt: {prompt_content}")

        try:
            response_obj = model.generate_content(prompt_content)
            response_text = response_obj.text.strip()
            logger.info(f"[{log_prefix}] Response received from model.")
            logger.debug(f"[{log_prefix}] Raw Response: {response_text}")
            return response_text
        except Exception as e:
            logger.error(f"[{log_prefix}] Failed to invoke Gemini model: {e}", exc_info=True)
            raise RuntimeError(f"Error communicating with the LLM: {e}")