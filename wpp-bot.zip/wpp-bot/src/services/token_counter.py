# src/bot/core/token_counter.py

import os
import csv
import logging
from datetime import datetime
from threading import Lock

logger = logging.getLogger(__name__)

class TokenCounter:
    """
    (PT) Gerencia a contagem de tokens de forma segura para threads, registrando
    cada chamada de modelo em um arquivo CSV.

    (EN) Manages token counting in a thread-safe manner, logging each
    model call to a CSV file.
    """

    def __init__(self, log_filename: str = "token_log.csv"):
        """
        (PT) Inicializa o contador de tokens.

        (EN) Initializes the token counter.

        Args:
            log_filename (str): O nome do arquivo CSV para salvar os logs de tokens.
                                O arquivo será criado na raiz do projeto.
        """
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
        self.log_file_path = os.path.join(project_root, log_filename)

        self._file_lock = Lock()
        
        self._initialize_log_file()
        logger.info(f"TokenCounter initialized. Logging to '{self.log_file_path}'")

    def _initialize_log_file(self):
        """
        (PT) Cria o arquivo de log CSV com o cabeçalho, se ele ainda não existir.
        Esta operação é protegida por um lock para segurança em ambientes concorrentes.

        (EN) Creates the CSV log file with its header if it doesn't already exist.
        This operation is protected by a lock for safety in concurrent environments.
        """
        with self._file_lock:
            if not os.path.exists(self.log_file_path):
                try:
                    with open(self.log_file_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f)
                        writer.writerow([
                            "timestamp",
                            "model_name",
                            "input_tokens_request"
                        ])
                except IOError as e:
                    logger.error(f"Failed to create token log file at {self.log_file_path}: {e}")

    def record_input_tokens(self, model_name: str, token_count: int):
        """
        (PT) Registra a contagem de tokens de uma única requisição no arquivo CSV.
        Este é o método que o LLMService chama.

        (EN) Records the token count of a single request to the CSV file.
        This is the method called by LLMService.

        Args:
            model_name (str): O nome do modelo que foi usado.
            token_count (int): A quantidade de tokens de entrada gastos na requisição.
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with self._file_lock:
            try:
                with open(self.log_file_path, 'a', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        timestamp,
                        model_name,
                        token_count
                    ])
            except IOError as e:
                logger.error(f"Failed to write to token log file {self.log_file_path}: {e}")

