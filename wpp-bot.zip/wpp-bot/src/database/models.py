# src/database/models.py

import json
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Conversation(Base):
    """
    (PT) Modelo de dados para persistir conversas do WhatsApp.
    (EN) Data model for persisting WhatsApp conversations.
    """
    __tablename__ = 'conversations'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    client_contact = Column(String(255), unique=True, nullable=False)
    current_step = Column(String(255), nullable=True)
    conversation_history = Column(Text, nullable=True)
    last_interaction_time = Column(DateTime, default=datetime.utcnow)
    conversation_status = Column(String(50), default='IN_PROGRESS')
    
    def __repr__(self):
        return f"<Conversation(client_contact='{self.client_contact}', status='{self.conversation_status}')>"
    
    def get_history_as_list(self):
        """
        (PT) Retorna o histórico da conversa como uma lista de dicionários.
        (EN) Returns the conversation history as a list of dictionaries.
        """
        if self.conversation_history:
            try:
                return json.loads(self.conversation_history)
            except json.JSONDecodeError:
                return []
        return []
    
    def set_history_from_list(self, history_list):
        """
        (PT) Define o histórico da conversa a partir de uma lista de dicionários.
        (EN) Sets the conversation history from a list of dictionaries.
        """
        self.conversation_history = json.dumps(history_list, ensure_ascii=False)
    
    def add_message_to_history(self, message_dict):
        """
        (PT) Adiciona uma mensagem ao histórico da conversa.
        (EN) Adds a message to the conversation history.
        """
        history = self.get_history_as_list()
        history.append(message_dict)
        self.set_history_from_list(history)

class DatabaseManager:
    """
    (PT) Gerenciador de conexão e operações do banco de dados SQLite.
    (EN) SQLite database connection and operations manager.
    """
    
    def __init__(self, database_url='sqlite:///conversations.db'):
        """
        (PT) Inicializa o gerenciador do banco de dados.
        (EN) Initializes the database manager.
        """
        self.engine = create_engine(database_url, echo=False)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        self.create_tables()
    
    def create_tables(self):
        """
        (PT) Cria as tabelas no banco de dados se elas não existirem.
        (EN) Creates the database tables if they don't exist.
        """
        Base.metadata.create_all(bind=self.engine)
    
    def get_session(self):
        """
        (PT) Retorna uma nova sessão do banco de dados.
        (EN) Returns a new database session.
        """
        return self.SessionLocal()

