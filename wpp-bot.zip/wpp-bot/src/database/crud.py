# src/database/crud.py

import logging
from datetime import datetime
from typing import Optional, List, Dict
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from src.database.models import Conversation

logger = logging.getLogger(__name__)

class ConversationCRUD:
    """
    (PT) Operações CRUD para a entidade Conversation.
    (EN) CRUD operations for the Conversation entity.
    """
    
    @staticmethod
    def get_conversation(db: Session, client_contact: str) -> Optional[Conversation]:
        """
        (PT) Busca uma conversa pelo contato do cliente.
        (EN) Retrieves a conversation by client contact.
        """
        try:
            return db.query(Conversation).filter(Conversation.client_contact == client_contact).first()
        except SQLAlchemyError as e:
            logger.error(f"Error retrieving conversation for {client_contact}: {e}")
            return None
    
    @staticmethod
    def create_conversation(db: Session, client_contact: str, current_step: str = None, 
                          conversation_history: List[Dict] = None, 
                          conversation_status: str = 'IN_PROGRESS') -> Optional[Conversation]:
        """
        (PT) Cria uma nova conversa.
        (EN) Creates a new conversation.
        """
        try:
            conversation = Conversation(
                client_contact=client_contact,
                current_step=current_step,
                conversation_status=conversation_status,
                last_interaction_time=datetime.utcnow()
            )
            
            if conversation_history:
                conversation.set_history_from_list(conversation_history)
            
            db.add(conversation)
            db.commit()
            db.refresh(conversation)
            logger.info(f"Created new conversation for {client_contact}")
            return conversation
        except SQLAlchemyError as e:
            logger.error(f"Error creating conversation for {client_contact}: {e}")
            db.rollback()
            return None
    
    @staticmethod
    def update_conversation(db: Session, client_contact: str, current_step: str = None,
                          conversation_history: List[Dict] = None,
                          conversation_status: str = None) -> Optional[Conversation]:
        """
        (PT) Atualiza uma conversa existente.
        (EN) Updates an existing conversation.
        """
        try:
            conversation = ConversationCRUD.get_conversation(db, client_contact)
            if not conversation:
                logger.warning(f"Conversation not found for {client_contact}")
                return None
            
            if current_step is not None:
                conversation.current_step = current_step
            
            if conversation_history is not None:
                conversation.set_history_from_list(conversation_history)
            
            if conversation_status is not None:
                conversation.conversation_status = conversation_status
            
            conversation.last_interaction_time = datetime.utcnow()
            
            db.commit()
            db.refresh(conversation)
            logger.info(f"Updated conversation for {client_contact}")
            return conversation
        except SQLAlchemyError as e:
            logger.error(f"Error updating conversation for {client_contact}: {e}")
            db.rollback()
            return None
    
    @staticmethod
    def add_message_to_conversation(db: Session, client_contact: str, message_dict: Dict) -> Optional[Conversation]:
        """
        (PT) Adiciona uma mensagem ao histórico da conversa.
        (EN) Adds a message to the conversation history.
        """
        try:
            conversation = ConversationCRUD.get_conversation(db, client_contact)
            if not conversation:
                # Se a conversa não existe, cria uma nova
                conversation = ConversationCRUD.create_conversation(
                    db, client_contact, conversation_history=[message_dict]
                )
                return conversation
            
            conversation.add_message_to_history(message_dict)
            conversation.last_interaction_time = datetime.utcnow()
            
            db.commit()
            db.refresh(conversation)
            logger.debug(f"Added message to conversation for {client_contact}")
            return conversation
        except SQLAlchemyError as e:
            logger.error(f"Error adding message to conversation for {client_contact}: {e}")
            db.rollback()
            return None
    
    @staticmethod
    def get_or_create_conversation(db: Session, client_contact: str) -> Optional[Conversation]:
        """
        (PT) Busca uma conversa existente ou cria uma nova se não existir.
        (EN) Retrieves an existing conversation or creates a new one if it doesn't exist.
        """
        conversation = ConversationCRUD.get_conversation(db, client_contact)
        if not conversation:
            conversation = ConversationCRUD.create_conversation(db, client_contact)
        return conversation
    
    @staticmethod
    def get_active_conversations(db: Session) -> List[Conversation]:
        """
        (PT) Retorna todas as conversas ativas (status IN_PROGRESS).
        (EN) Returns all active conversations (status IN_PROGRESS).
        """
        try:
            return db.query(Conversation).filter(Conversation.conversation_status == 'IN_PROGRESS').all()
        except SQLAlchemyError as e:
            logger.error(f"Error retrieving active conversations: {e}")
            return []
    
    @staticmethod
    def close_conversation(db: Session, client_contact: str, final_status: str, summary: str = None) -> Optional[Conversation]:
        """
        (PT) Fecha uma conversa com um status final.
        (EN) Closes a conversation with a final status.
        """
        try:
            conversation = ConversationCRUD.get_conversation(db, client_contact)
            if not conversation:
                logger.warning(f"Conversation not found for {client_contact}")
                return None
            
            conversation.conversation_status = final_status
            conversation.last_interaction_time = datetime.utcnow()
            
            # Se houver um resumo, adiciona como uma mensagem especial no histórico
            if summary:
                summary_message = {
                    "type": "summary",
                    "content": summary,
                    "timestamp": datetime.utcnow().isoformat()
                }
                conversation.add_message_to_history(summary_message)
            
            db.commit()
            db.refresh(conversation)
            logger.info(f"Closed conversation for {client_contact} with status {final_status}")
            return conversation
        except SQLAlchemyError as e:
            logger.error(f"Error closing conversation for {client_contact}: {e}")
            db.rollback()
            return None

