# src/bot/core/conversation_context.py

import json
import logging
from typing import Dict, List, Any

from langchain_core.messages import HumanMessage
from src.utils.helpers import format_chat_history

logger = logging.getLogger(__name__)

class ConversationContext:
    """
    (PT) Gerencia e formata o contexto da conversa (roteiro e histórico)
    para ser enviado ao LLM.

    (EN) Manages and formats the conversation context (script and history)
    to be sent to the LLM.
    """

    def __init__(self, script: Dict[str, Any], chat_history: List[Dict]):
        """
        (PT) Inicializa o contexto da conversa.

        (EN) Initializes the conversation context.

        Args:
            script (Dict[str, Any]): O roteiro de vendas ou de interação.
            chat_history (List[Dict]): O histórico de mensagens da conversa.
        """
        self.script = script
        self.chat_history = chat_history

        self._base_chat_messages = self._prepare_base_chat()

    def _prepare_base_chat(self) -> List[HumanMessage]:
        """
        (PT) Formata o roteiro e o histórico em objetos HumanMessage para o contexto base.
        Esta formatação é o que o LLM usará como sua "memória" da conversa.

        (EN) Formats the script and history into HumanMessage objects for the base context.
        This formatting is what the LLM will use as its "memory" of the conversation.

        Returns:
            List[HumanMessage]: Uma lista de mensagens formatadas para o contexto da LLemon.
        """
        history_formatted, _ = format_chat_history(self.chat_history)
        script_formatted = json.dumps(self.script, ensure_ascii=False, indent=2)

        logger.debug(f"Prepared context. Script: {script_formatted}")
        logger.debug(f"Prepared context. History: {history_formatted}")

        return [
            HumanMessage(content=f"Este é o roteiro a ser seguido:\n{script_formatted}"),
            HumanMessage(content=f"Essas são as mensagens do histórico:\n{history_formatted}"),
        ]

    def get_base_chat_messages(self) -> List[HumanMessage]:
        """
        (PT) Retorna a lista de mensagens base (roteiro + histórico) para o contexto da LLM.

        (EN) Returns the list of base messages (script + history) for the LLM's context.

        Returns:
            List[HumanMessage]: A lista de objetos HumanMessage pré-formatados.
        """
        return self._base_chat_messages
