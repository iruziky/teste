# src/bot/ai_bot.py

import yaml
import logging
import os
import json
from typing import List, Dict, Any

from src.services.llm_service import LLMService
from src.dialogue_manager.unified_prompts import gerar_prompt_unificado
from src.utils.helpers import format_chat_history, clean_llm_response

logger = logging.getLogger(__name__)

class DialogueHandler:
    """
    (PT) Classe principal para orquestrar as interações do bot usando uma única chamada de IA.
    Usa a IA para analisar o contexto, decidir a melhor ação e gerar a resposta final.

    (EN) Main class for orchestrating bot interactions using a single AI call.
    Uses AI to analyze context, decide the best action, and generate the final response.
    """

    def __init__(self, llm_service: LLMService, script_path: str, include_analysis_in_prompt: bool = False):
        self.llm_service = llm_service
        self.script = self._load_script(script_path)
        self.include_analysis = include_analysis_in_prompt

    def _load_script(self, script_path: str) -> Dict[str, Any]:
        """ (PT) Carrega o roteiro de um arquivo YAML. (EN) Loads the script from a YAML file. """
        try:
            if not os.path.isabs(script_path):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
                script_path = os.path.join(project_root, script_path)
            with open(script_path, 'r', encoding='utf-8') as f:
                logger.info(f"Loading script from: {script_path}")
                return yaml.safe_load(f)
        except FileNotFoundError as e:
            logger.error(f"Failed to load script file at {script_path}: {e}")
            raise
        except yaml.YAMLError as e:
            logger.error(f"Failed to parse script file at {script_path}: {e}")
            raise
        except Exception as e:
            logger.error(f"An unexpected error occurred while loading script from {script_path}: {e}")
            raise

    def generate_reply(self, user_message: str, chat_history: List[Dict]) -> Dict[str, Any]:
        """
        (PT) O método principal que gera uma decisão estruturada para uma mensagem de usuário
        usando uma única chamada de IA para uma lógica unificada.
        Retorna um dicionário contendo a mensagem de resposta, o status final da conversa
        e um resumo, se aplicável.
        
        (EN) The main method that generates a structured decision for a user message
        using a single AI call for unified logic.
        Returns a dictionary containing the reply message, the final conversation status,
        and a summary, if applicable.
        """
        history_formatted = format_chat_history(chat_history)

        prompt = gerar_prompt_unificado(
            history_messages=history_formatted,
            received_message=user_message,
            script_data=self.script,
            include_analysis=self.include_analysis
        )

        raw_llm_response = self.llm_service.generate_text(
            model_name='pro',
            prompt_content=prompt, 
            log_prefix="Unified Dialogue Action"
        )
        
        logger.info(f"RAW LLM RESPONSE RECEIVED: ---{raw_llm_response}---")
        
        try:
            cleaned_response_str = clean_llm_response(raw_llm_response)
            if not cleaned_response_str:
                raise json.JSONDecodeError("Empty response after cleaning", "", 0)

            response_data = json.loads(cleaned_response_str)
            

            action_status = response_data.get("action_status", "UNKNOWN_STATUS")
            reply_message = response_data.get("response_to_send")
            summary = response_data.get("conversation_summary")
            analysis = response_data.get("analysis", "No analysis provided.")

            logger.info(f"AI decision status: {action_status}")
            logger.debug(f"AI analysis: {analysis}")

            if action_status == "STOP_CONVERSATION_GOOD":
                logger.info(f"Conversation ended successfully. Summary: {summary}")
                return {
                    "reply_message": reply_message or "Obrigado! Tenha um ótimo dia.",
                    "final_status": "STOP_SUCCESS",
                    "summary": summary
                }
            
            elif action_status == "STOP_CONVERSATION_BAD":
                logger.warning("Conversation stopped by user request or frustration.")
                return {
                    "reply_message": reply_message or "Entendido.",
                    "final_status": "STOP_BAD_LEAD",
                    "summary": None
                }

            elif action_status in ["CONTINUE_ON_SCRIPT", "CONTINUE_OFF_SCRIPT"]:
                if not reply_message:
                    logger.error("AI indicated to continue but sent no reply message.")
                    return self._get_fallback_decision()
                
                return {
                    "reply_message": reply_message,
                    "final_status": "CONTINUE",
                    "summary": None
                }
            
            else:
                logger.error(f"Unknown action_status received from AI: '{action_status}'")
                return self._get_fallback_decision()

        except json.JSONDecodeError:
            logger.error(f"Failed to decode JSON from LLM response. Raw response: '{raw_llm_response}'")
            return self._get_fallback_decision()
        except Exception as e:
            logger.error(f"An unexpected error occurred while processing LLM response: {e}")
            return self._get_fallback_decision()

    def _get_fallback_decision(self) -> Dict[str, Any]:
        """
        (PT) Retorna uma DECISÃO de fallback segura em caso de erro.
        (EN) Returns a safe fallback DECISION in case of an error.
        """
        logger.warning("Returning a generic fallback decision due to an error.")
        return {
            "reply_message": "Desculpe, não consegui processar sua mensagem no momento. Poderia repetir, por favor?",
            "final_status": "ERROR",
            "summary": None
        }