import logging
import time
import random

from src.config import Config
from src.approach.contact_processor import ContactProcessor
from src.services.waha import WahaClient

logger = logging.getLogger(__name__)

class MassSendHandler:
    """
    (PT) Gerencia e executa a tarefa de envio de mensagens em massa.
    (EN) Manages and executes the mass messaging task.
    """
    def __init__(self, waha_client: WahaClient, config: Config):
        """
        (PT) Inicializa o manipulador de envio em massa.
        (EN) Initializes the mass sending handler.

        Args:
            waha_client (WahaClient): A instância do cliente WAHA a ser usada para o envio.
        """
        self.config = config
        self.waha_client = waha_client

    def _handle_mass_send(self, csv_contacts):
        """ (PT) Executa o envio de mensagens em massa. (EN) Executes mass messaging. """
        logger.info("Starting mass messaging process.")
        
        processor = ContactProcessor()
        contacts_to_send = processor.extract_contacts_from_csv(csv_contacts)
        contacts_to_ignore = processor.extract_contacts_from_csv(self.config.CONTACTS_TO_IGNORE_SEND)

        for contact in contacts_to_ignore:
            contacts_to_send.remove(contact)

        if contacts_to_send is not None:
            print(f"Contatos encontrados: {contacts_to_send}")
        else:
            print("Falha ao processar os contatos.")

        for contact_number in contacts_to_send:
            try:
                message_text = "Oi, tudo bem?"
                self.waha_client.send_text(chat_id=contact_number, text=message_text)
                contacts_to_ignore.append(contact_number)
                random_delay = random.uniform(25, 40)
                logger.info(f"Message sent to {contact_number}. Waiting {random_delay:.2f} seconds...")
                time.sleep(random_delay)
            except Exception as e:
                logger.error(f"An error occurred while sending to {contact_number}: {e}")
        logger.info("Mass messaging process finished.")