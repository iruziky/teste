import csv
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

class ContactProcessor:
    """
    (PT) Classe responsável por processar arquivos CSV de contatos.
    (EN) Class responsible for processing contact CSV files.
    """

    def extract_contacts_from_csv(self, file_path: str, column_name: str = "Telefone") -> Optional[List[str]]:
        """
        (PT) Lê um arquivo CSV e extrai todos os valores de uma coluna específica.

        (EN) Reads a CSV file and extracts all values from a specific column.

        Args:
            file_path (str): O caminho para o arquivo CSV.
            column_name (str): O nome da coluna da qual extrair os contatos. O padrão é "Telefone".

        Returns:
            Optional[List[str]]: Uma lista de contatos, ou None se ocorrer um erro.
        """
        phone_numbers = []
        try:
            with open(file_path, mode='r', encoding='utf-8-sig') as csv_file:
                csv_reader = csv.DictReader(csv_file)
                
                for row in csv_reader:
                    phone_number = row.get(column_name)
                    if phone_number:
                        phone_numbers.append(phone_number.strip())
                    else:
                        logger.warning(f"Column '{column_name}' not found in a row in file {file_path}.")

            logger.info(f"Successfully extracted {len(phone_numbers)} contacts from {file_path}.")
            return phone_numbers

        except FileNotFoundError:
            logger.error(f"File not found at path: {file_path}")
            return None
        except KeyError:
            logger.error(f"The required column '{column_name}' was not found in the CSV header of file {file_path}.")
            return None
        except Exception as e:
            logger.error(f"An unexpected error occurred while reading the CSV file: {e}", exc_info=True)
            return None
