# src/api/__init__.py

import os
import logging
from flask import Flask
import redis

from src.config import Config
from src.api.routes import main_bp

logger = logging.getLogger(__name__)

def create_app(config_class=Config):
    """
    (PT) A 'Application Factory'. Cria e configura a instância principal da aplicação Flask.
    Este padrão torna a aplicação mais modular e testável.

    (EN) The 'Application Factory'. Creates and configures the main Flask application instance.
    This pattern makes the application more modular and testable.

    Args:
        config_class: A classe de configuração a ser usada.

    Returns:
        A instância da aplicação Flask configurada.
    """
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    
    app = Flask(
        __name__,
        instance_relative_config=False,
        static_folder=os.path.join(project_root, 'static'),
        template_folder=os.path.join(project_root, 'templates')
    )

    app.config.from_object(config_class)

    try:
        app.redis_client = redis.StrictRedis(
            host=app.config['REDIS_HOST'],
            port=app.config['REDIS_PORT'],
            decode_responses=True
        )
        app.redis_client.ping()
        logger.info("Successfully connected to Redis from Flask app.")
    except redis.exceptions.ConnectionError as e:
        logger.error(f"Could not connect to Redis from Flask app: {e}")
        app.redis_client = None

    app.register_blueprint(main_bp)
    
    app.secret_key = app.config['SECRET_KEY']

    return app