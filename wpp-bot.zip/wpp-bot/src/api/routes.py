# src/api/routes.py

import os
import logging
import json
import time
from flask import Blueprint, current_app, jsonify, render_template, request, send_from_directory
from werkzeug.utils import secure_filename
import requests
from flask import url_for, redirect, session
from src.services.calendar_client import GoogleCalendarClient

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    calendar_connected = 'google_refresh_token' in session
    return render_template('index.html', calendar_connected=calendar_connected)


# --- ROTAS PARA AUTENTICAÇÃO GOOGLE ---

@main_bp.route('/google-auth/start')
def google_auth_start():
    """
    (PT) Inicia o fluxo de autorização OAuth 2.0, redirecionando o utilizador para o Google.
    (EN) Starts the OAuth 2.0 authorization flow by redirecting the user to Google.
    """
    secrets_path = os.path.join(current_app.root_path, 'client_secret.json')
    redirect_uri = url_for('main.google_auth_callback', _external=True)

    client = GoogleCalendarClient(client_secrets_path=secrets_path, redirect_uri=redirect_uri)
    auth_url = client.get_auth_url()

    if auth_url:
        return redirect(auth_url)
    else:
        return "Erro: Não foi possível gerar o URL de autorização. Verifique os logs.", 500


@main_bp.route('/google-auth/callback')
def google_auth_callback():
    """
    (PT) Rota de callback que o Google chama após o utilizador dar permissão.
    Guarda o token na sessão e redireciona para a página inicial.
    (EN) Callback route that Google calls after the user grants permission.
    Saves the token in the session and redirects to the homepage.
    """
    secrets_path = os.path.join(current_app.root_path, 'client_secret.json')
    redirect_uri = url_for('main.google_auth_callback', _external=True)
    
    authorization_code = request.args.get('code')

    client = GoogleCalendarClient(client_secrets_path=secrets_path, redirect_uri=redirect_uri)
    refresh_token = client.fetch_token(authorization_code)

    if refresh_token:
        session['google_refresh_token'] = refresh_token
        logger.info("Successfully obtained and stored refresh token in the user's session.")
        
        return redirect(url_for('main.index'))
    else:
        return "<h1>Falha na Autenticação</h1><p>Não foi possível obter o token. Verifique os logs do servidor.</p>", 400


@main_bp.route('/upload-and-start', methods=['POST'])
def upload_and_start():
    if 'contact_list' not in request.files:
        return jsonify({'error': 'Nenhum arquivo enviado.'}), 400

    file = request.files['contact_list']
    if file.filename == '':
        return jsonify({'error': 'Nenhum arquivo selecionado.'}), 400

    if file and file.filename.endswith('.csv'):
        filename = secure_filename(file.filename)
        upload_folder = os.path.join(current_app.root_path, 'uploads') 
        os.makedirs(upload_folder, exist_ok=True)
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)

        job = {"job_type": "process_csv_and_send", "payload": {"file_path": file_path}}
        redis_client = current_app.redis_client
        redis_client.lpush(current_app.config['REDIS_QUEUE_KEY'], json.dumps(job))

        return jsonify({'message': f'Arquivo "{filename}" recebido. Campanha em processamento.'}), 202

    return jsonify({'error': 'Arquivo inválido. Por favor, envie um .csv'}), 400

@main_bp.route('/qrcode.png')
def get_qr_image():
    return send_from_directory(current_app.static_folder, 'qrcode.png')

@main_bp.route('/generate-qr', methods=['POST'])
def generate_qr():
    """(PT) Lida com a requisição de geração de QR code vinda do frontend."""
    """(EN) Handles the QR code generation request from the frontend."""
    logger.info("Received request to generate QR code.")
    waha_url = current_app.config['WAHA_URL']
    session_name = current_app.config['SESSION_NAME']
    
    try:
        requests.post(f"{waha_url}/api/sessions/{session_name}/stop", timeout=10)
        time.sleep(1)

        start_payload = {
            "name": session_name,
            "config": {"noweb": {"store": {"enabled": True, "full_sync": True}}}
        }
        start_response = requests.post(f"{waha_url}/api/sessions/start", json=start_payload, timeout=15)
        start_response.raise_for_status()

        start_time = time.time()
        while time.time() - start_time < 25:
            status_response = requests.get(f"{waha_url}/api/sessions/{session_name}", timeout=10)
            status_response.raise_for_status()
            status = status_response.json().get("status")
            if status == "SCAN_QR_CODE": break
            if status == "WORKING": return jsonify({'success': True, 'status': 'ALREADY_CONNECTED'})
            time.sleep(2)
        else:
            raise requests.exceptions.Timeout("QR code generation timed out.")

        qr_url = f"{waha_url}/api/{session_name}/auth/qr?format=image"
        qr_response = requests.get(qr_url, timeout=10)
        qr_response.raise_for_status()
        
        if qr_response.content:
            os.makedirs(current_app.static_folder, exist_ok=True)
            with open(os.path.join(current_app.static_folder, "qrcode.png"), "wb") as f:
                f.write(qr_response.content)
            return jsonify({'success': True, 'status': 'QR_CODE_READY'})
        else:
            raise ValueError("QR code image response was empty.")

    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to communicate with WAHA service: {e}")
        return jsonify({'success': False, 'error': "Could not connect to the WhatsApp service."}), 503
    except Exception as e:
        logger.error(f"An unexpected error occurred in generate_qr: {e}", exc_info=True)
        return jsonify({'success': False, 'error': "An internal server error occurred."}), 500


@main_bp.route('/chatbot/webhook/', methods=['POST'])
def webhook():
    """(PT) Recebe os eventos do WAHA e os enfileira no Redis para processamento."""
    """(EN) Receives events from WAHA and queues them in Redis for processing."""
    redis_client = current_app.redis_client
    if not redis_client:
        logger.critical("Redis is not connected. Cannot process webhook.")
        return jsonify({'status': 'error', 'message': 'Internal service is not available'}), 503
        
    try:
        data = request.json
        event_id = data.get('id')
        if event_id:
            redis_key = f"webhook_event_seen:{event_id}"
            if not redis_client.set(redis_key, "1", nx=True, ex=60):
                return jsonify({'status': 'duplicate_ignored'}), 200

        payload = data.get('payload', {})
        chat_id = payload.get('from')
        message = payload.get('body')

        if not all([chat_id, message]):
            return jsonify({'status': 'error', 'message': 'Invalid payload'}), 400

        job_payload = {"chat_id": chat_id, "message": message}
        queue_key = current_app.config['REDIS_QUEUE_KEY']

        job = {"job_type": "process_message", "payload": job_payload}
        redis_client.lpush(queue_key, json.dumps(job))
        return jsonify({'status': 'received'}), 200

    except Exception as e:
        logger.error(f"Error in webhook: {e}", exc_info=True)
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500
