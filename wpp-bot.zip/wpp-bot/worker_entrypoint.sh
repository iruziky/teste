#!/bin/sh

# Desativa o buffer do Python para que os logs apareçam imediatamente.
export PYTHONUNBUFFERED=1

echo "--- [Worker Entrypoint] Launching Python application with auto-reload... ---"

exec watchmedo auto-restart --directory=./src --pattern=*.py --recursive -- python -m src.worker.main
