# WhatsApp Sales Bot com IA Gemini

Este repositório contém um bot de vendas proativo para WhatsApp, construído com Python, Flask e a IA do Google Gemini. O bot é projetado para iniciar conversas, seguir um roteiro de vendas dinâmico e usar a inteligência artificial para entender as respostas do cliente e determinar os próximos passos da conversa.

O projeto é totalmente containerizado com Docker e usa uma arquitetura de API + Worker com uma fila de tarefas Redis para garantir alta performance e escalabilidade.

## ✨ Principais Funcionalidades

* **Lógica de Vendas Proativa:** O bot é capaz de iniciar conversas e guiar o cliente através de um roteiro de vendas predefinido.
* **Processamento Inteligente de Respostas:** Utiliza o Google Gemini para analisar as respostas abertas dos clientes e determinar a etapa correta da conversa.
* **Arquitetura Escalável:** Usa uma fila de tarefas (Redis) para desacoplar o recebimento de mensagens (API Flask) do processamento pesado (Worker), garantindo que a aplicação permaneça responsiva sob alta carga.
* **Debounce de Mensagens:** Agrupa mensagens enviadas rapidamente pelo usuário para processá-las como um único pensamento, economizando chamadas de API e melhorando a compreensão do contexto.
* **Pronto para Produção:** Totalmente containerizado com Docker e Docker Compose para fácil deploy em qualquer servidor.
* **Código Modular:** Segue as melhores práticas de desenvolvimento, com separação de responsabilidades, injeção de dependência e uma estrutura de pastas clara.

## 🛠️ Tecnologias Utilizadas

* **Backend:** Python 3.11, Flask, Gunicorn
* **IA & Machine Learning:** Google Gemini Pro & Flash
* **Comunicação WhatsApp:** [WAHA (WhatsApp HTTP API)](https://waha.devlike.pro/)
* **Fila de Tarefas & Cache:** Redis
* **Containerização:** Docker & Docker Compose

## 🏗️ Arquitetura do Sistema

O sistema opera em um fluxo desacoplado para garantir performance e resiliência:

**Fluxo:** `Usuário` -> `WAHA` -> `API (Flask)` -> `Fila (Redis)` -> `Worker` -> `IA (Gemini)` -> `Worker` -> `WAHA` -> `Usuário`

1.  **WAHA:** Recebe uma mensagem do WhatsApp e a envia via webhook para a nossa API.
2.  **API (Flask):** Recebe o webhook, valida os dados e rapidamente coloca um "job" (tarefa) na fila do Redis. Sua única função é ser rápida e nunca bloquear.
3.  **Redis:** Atua como a fila de tarefas, garantindo que nenhuma mensagem seja perdida, mesmo que o worker esteja ocupado.
4.  **Worker:** Um processo em segundo plano que observa a fila do Redis. Ao receber um job, ele executa toda a lógica pesada:
    * Gerencia o "debounce" de mensagens.
    * Constrói o contexto da conversa.
    * Chama o **LLMService** para se comunicar com a IA do Gemini.
    * Determina a próxima resposta e a envia de volta através do WAHA.

## 🚀 Como Rodar o Projeto

Siga os passos abaixo para configurar e executar o projeto em seu ambiente local ou em um servidor.

### Pré-requisitos

* Docker (`docker`)
* Docker Compose (`docker-compose`)

### 1. Clone o Repositório

```bash
git@github.com:iruziky/Wpp-Bot-AI.git
cd Wpp-Bot-AI
```

### 2. Configure as Variáveis de Ambiente

O projeto usa um arquivo `.env` para gerenciar chaves de API e outras configurações.

Crie um arquivo chamado `.env` na raiz do projeto e adicione suas chaves:

```env
# Chave de API do Google Gemini
GEMINI_API_KEY="sua_chave_gemini_aqui"
```

### 3. Suba os Containers

Com o Docker em execução, use o Docker Compose para construir as imagens e iniciar todos os serviços:

```bash
docker-compose up --build -d
```

* `--build`: Força a reconstrução das imagens se houver mudanças no `Dockerfile`.
* `-d`: Roda os containers em modo "detached" (em segundo plano).

### 4. Conecte-se ao WhatsApp

1.  Abra seu navegador e acesse `http://localhost:5000`.
2.  Clique no botão "Gerar QR Code".
3.  Escaneie o QR Code com o seu aplicativo WhatsApp (em *Aparelhos conectados*).
4.  Aguarde a página confirmar que a conexão foi bem-sucedida.

Seu bot agora está online e pronto para receber e enviar mensagens!

## 📁 Estrutura do Projeto

O código-fonte está organizado dentro da pasta `src/` para manter o projeto limpo e modular.

```
src/
├── api/             # Lógica da API Flask (rotas, etc.)
├── assets/          # Arquivos de dados, como o roteiro em JSON
├── bot/             # O "cérebro" do bot, com toda a lógica da IA
│   ├── core/        # Serviços centrais da IA (LLM, contexto)
│   └── prompts/     # Módulo para construir os prompts enviados à IA
├── config.py        # Objeto de configuração centralizado
├── services/        # Clientes para se comunicar com APIs externas (WAHA)
├── utils/           # Funções de ajuda e utilitários
└── worker/          # Lógica do worker que processa as tarefas
```