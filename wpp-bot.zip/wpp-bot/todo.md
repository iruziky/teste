## Tarefas do Projeto

### Fase 1: Extração e análise inicial do código
- [x] Extrair o arquivo ZIP do projeto.
- [x] Listar o conteúdo do diretório do projeto.
- [x] Analisar os arquivos do projeto para identificar pontos de persistência.

### Fase 2: Análise de persistência de dados
- [x] Definir o esquema do banco de dados para persistência.
- [x] Identificar as classes/funções que precisam ser modificadas para a persistência.

### Fase 3: Implementação da persistência com SQLite
- [x] Adicionar dependências para SQLite (SQLAlchemy).
- [x] Criar modelos de dados para as entidades a serem persistidas.
- [x] Implementar a lógica de persistência (salvar, carregar, atualizar) nos pontos identificados.

### Fase 4: Configuração e teste do ambiente Docker
- [x] Atualizar o Dockerfile e docker-compose.yml para incluir o banco de dados SQLite.
- [x] Construir e levantar os contêineres Docker.
- [x] Testar a execução do ambiente Docker.

### Fase 5: Documentação e entrega final
- [ ] Gerar o código-fonte completo com as alterações.
- [ ] Fornecer instruções claras para a execução do ambiente de desenvolvimento.

## Esquema do Banco de Dados (SQLite)

**Tabela: `conversations`**
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `client_contact` (TEXT UNIQUE NOT NULL) - O chat_id do cliente
- `current_step` (TEXT) - A etapa atual da conversa (referência ao roteiro YAML)
- `conversation_history` (TEXT) - Histórico completo da conversa (JSON)
- `last_interaction_time` (DATETIME) - Hora da última interação
- `conversation_status` (TEXT) - Status da conversa (STOP_CONVERSATION_GOOD, STOP_CONVERSATION_BAD, IN_PROGRESS)

## Classes/Funções a serem modificadas:
- `src/worker/main.py`: A classe `Worker` e os métodos `_process_debounced_message` e `_handle_user_message` precisarão ser modificados para interagir com o banco de dados SQLite para salvar e carregar o estado da conversa.
- `src/dialogue_manager/handler.py`: O método `generate_reply` pode precisar de ajustes para usar o `current_step` e o `conversation_history` do banco de dados.
- Novas classes/módulos para o modelo de dados e operações de banco de dados (e.g., `src/database/models.py`, `src/database/crud.py`).


